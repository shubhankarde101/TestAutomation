package com.fresco;

public class TestData {
	private TestBusiness testBusiness;

	public TestBusiness getTestBusiness() {
		return testBusiness;
	}
}
