package com.fresco;

public class TestBusiness {
	private TestService testService;

	public TestService getTestService() {
		return testService;
	}
}
