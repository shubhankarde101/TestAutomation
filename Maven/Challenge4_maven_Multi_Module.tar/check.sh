#!/bin/sh
SCORE=0  
mvn clean compile package | tee .output.txt
TEST_1=$(find /projects/challenge/data/target/data-*.jar | wc -l)
TEST_2=$(find /projects/challenge/business/target/business-*.jar | wc -l)
TEST_3=$(find /projects/challenge/service/target/service-*.jar | wc -l)
TEST_4=$(grep -io -e "BUILD SUCCESS" -e "SUCCESS" -e "MavenMultiModule" -e "data" -e "business" -e "service" ./.output.txt | wc -l)
if [ "$TEST_1" -eq 1 ]
then SCORE=$(($SCORE + 30))
fi;
if [ "$TEST_2" -eq 1 ]
then SCORE=$(($SCORE + 30))
fi;
if [ "$TEST_3" -eq 1 ]
then SCORE=$(($SCORE + 30))
fi;
if [ "$TEST_4" -ge 13 ]
then SCORE=$(($SCORE + 10))
fi;
echo "FS_SCORE:$SCORE%"
  