package javaApp;

public class EvenSum {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		int even[] = new int[num];
		int sum = 0,j = 0;
		//Insert your code here

    int evennums = 1;
		System.out.println(evennums);
		System.out.println(sum);
	}
}
