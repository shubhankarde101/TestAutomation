#!/bin/sh
apt update
apt install maven
mvn clean
