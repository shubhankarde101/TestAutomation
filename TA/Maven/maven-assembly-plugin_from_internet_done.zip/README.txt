Predefined assemblies
https://maven.apache.org/plugins/maven-assembly-plugin/descriptor-refs.html

Assembly descriptor
https://maven.apache.org/plugins/maven-assembly-plugin/assembly.html