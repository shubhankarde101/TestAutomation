#!/bin/sh
pass=0
fail=0  
mvn clean compile package | tee .output.txt
mvn clean compile package | tee .output.txt
TEST_1=$(find /projects/challenge/target/assembly-plugin-*-bin.zip | wc -l)
TEST_2=$(find /projects/challenge/target/assembly-plugin-*-project.zip | wc -l)
TEST_3=$(find /projects/challenge/target/assembly-plugin-*-bin.tar.gz | wc -l)
TEST_4=$(find /projects/challenge/target/assembly-plugin-*-project.tar.gz | wc -l)
TEST_5=$(find /projects/challenge/target/assembly-plugin-*-ourAssembly.jar | wc -l)
TEST_6=$(find /projects/challenge/target/assembly-plugin-*.jar | wc -l)
TEST_7=$(grep -io "BUILD SUCCESS" /projects/challenge/.output.txt | wc -l)
TEST_8=$(grep -io -e "<format>jar</format>" -e "<include>test.txt</include>" /projects/challenge/assembly/ourAssembly.xml | wc -l)
TEST_9=$(grep -io -e "<artifactId>maven-assembly-plugin</artifactId>" -e "<descriptorRef>bin</descriptorRef>" -e "<descriptorRef>project</descriptorRef>" -e "<descriptor>assembly/ourAssembly.xml</descriptor>" /projects/challenge/pom.xml | wc -l)
if [ "$TEST_1" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_2" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_3" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_4" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_5" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_6" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_7" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_8" -ge 2 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_9" -ge 4 ]
then ((pass++))
else
    ((fail++))
fi;
echo "Total testcase: 9"
echo "Total testcase passed: $pass"
echo "Total testcase fail: $fail"
echo "total score: $(( ($pass * 100) / 9))"
   