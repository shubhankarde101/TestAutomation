#!/bin/sh
pass=0
fail=0
TEST_1=$(find ChildPOM/target/surefire-reports/*.xml | wc -l)
TEST_2=$(find ChildPOM/target/checkstyle-result.xml | wc -l)
TEST_3=$(find ChildPOM/target/checkstyle-checker.xml | wc -l)
TEST_4=$(grep -io -e "<parent>" -e "<groupId>ParentPOM</groupId>" -e "<relativePath>../ParentPOM/pom.xml</relativePath>" ChildPOM/pom.xml | wc -l)
TEST_5=$(grep -io -e "Tests run: 1" -e "Failures: 0" -e "Errors: 0" -e "BUILD SUCCESS" ChildPOM/.output.txt | wc -l)
TEST_6=$(grep -io -e "maven-surefire-report-plugin" -e "maven-checkstyle-plugin" ParentPOM/pom.xml | wc -l)
if [ "$TEST_1" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_2" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_3" -eq 1 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_4" -ge 3 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_5" -ge 7 ]
then ((pass++))
else
    ((fail++))
fi;
if [ "$TEST_6" -ge 2 ]
then ((pass++))
else
    ((fail++))
fi;
echo "Total testcase: 6"
echo "Total testcase passed: $pass"
echo "Total testcase fail: $fail"
echo "total score: $(( ($pass * 100) / 6))"