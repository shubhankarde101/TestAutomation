#!/bin/sh/
cd ChildPOM; mvn clean install test checkstyle:checkstyle | tee .output.txt