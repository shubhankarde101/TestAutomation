package com.fresco;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SampleTest {
	@Test
	public void testString() {
		String str = Sample.getMessage();
		assertEquals("POM file configured successsfully",str);
	}
}
