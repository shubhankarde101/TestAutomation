package com.fresco;

public class Sample {
	public static String getMessage() {
		//Write your code here
		return "POM file configured successsfully";
	}

	public static void main(String args[]) {
    //Test your code here
    System.out.println(getMessage());
	}
}
