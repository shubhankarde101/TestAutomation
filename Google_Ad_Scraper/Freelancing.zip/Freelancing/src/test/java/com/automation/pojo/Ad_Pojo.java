package com.automation.pojo;

public class Ad_Pojo {
	
	private String ad_Url;
	
	private String ad_Context;
	
	public String getAd_Url() {
		return ad_Url;
	}

	public void setAd_Url(String ad_Url) {
		this.ad_Url = ad_Url;
	}

	public String getAd_Context() {
		return ad_Context;
	}

	public void setAd_Context(String ad_Context) {
		this.ad_Context = ad_Context;
	}		

}
